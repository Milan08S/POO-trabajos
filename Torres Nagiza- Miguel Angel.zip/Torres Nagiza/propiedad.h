#ifndef PROPIEDAD_H
#define PROPIEDAD_H

#include <iostream>

using std::cout;
using std::cin;
using std::string;

class Propiedad{
    private:
        double idPropiedad;
        int piso;
        float area;
        bool parqueadero;
    public:
        void pagarRecargo( float );
        void setidPropiedad( double idPropiedad );
        void setPiso( int piso );
        void setArea( float area );
        void setParqueadero( bool parqueadero );
        void DatosPropiedad();
        int getParqueadero();
};

#endif