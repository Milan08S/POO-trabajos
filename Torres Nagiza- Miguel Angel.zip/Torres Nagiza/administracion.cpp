#include <iostream>
#include "administracion.h" 

void Administracion::Informacion(){
    Propietario propieta1, propieta2, propieta3, propieta4;

    propieta1.setNombre( "Debora Vilar" ); //aqui se coloca la informacion en las clases
    propieta1.setIdentificacion( 20202492 );
    propieta2.setNombre( "Ignacio Rodríguez " );
    propieta2.setIdentificacion( 30458452  );
    propieta3.setNombre( "Erika Muñoz " );
    propieta3.setIdentificacion( 1058845781 );
    propieta4.setNombre( "Modesto Villaverde " );
    propieta4.setIdentificacion( 31321432 );

    Propiedad prop1, prop2, prop3, prop4; //aqui creamos las propiedades

    prop1.setidPropiedad( 101 ); //Le asignamos la id a las propiedades
    prop2.setidPropiedad( 901 );
    prop3.setidPropiedad( 701  );
    prop4.setidPropiedad( 502 );

    prop1.setPiso( 10 ); //Le asignamos el piso a la propiedad
    prop2.setPiso( 9 );
    prop3.setPiso( 7 );
    prop4.setPiso( 5 );

    prop1.setArea( 160 ); //Le asignamos el area a cada propiedad
    prop2.setArea( 30 );
    prop3.setArea( 45 );
    prop4.setArea( 60 );

    prop1.setParqueadero( true );
    prop2.setParqueadero( false );
    prop3.setParqueadero( true );
    prop4.setParqueadero( false );

    propieta1.setPropiedad( prop1 ); //Le asignamos la propiedad al propietario
    propieta2.setPropiedad( prop2 );
    propieta3.setPropiedad( prop3 );
    propieta4.setPropiedad( prop4 );

    //incluir los propietarios en el vector(lista)

    propietarios.push_back( propieta1 ); //push back es como el append de python
    propietarios.push_back( propieta2) ;
    propietarios.push_back( propieta3 );
    propietarios.push_back( propieta4 );

    propiedades.push_back( prop1 );
    propiedades.push_back( prop2 );
    propiedades.push_back( prop3 );
    propiedades.push_back( prop4 );
    
    return;
}

void Administracion::imprimirUnPropietario()
{
}

void Administracion::imprimirPropietarios()
{
    // Recorrer el arreglo e imprimir todos los propietarios
    for (int i = 0; i < propietarios.size(); i++)
    {
        propietarios[ i ].Datospropietario();
    }
}

void Administracion::numeroParqueadero(){
    int num = 0;
    for( int i = 0; i < propietarios.size(); i++ ){
        if( propiedades[ i ].getParqueadero() == true ){
            num++;
        }
    }
    cout << "El numero de propietarios con parqueadero es " << num << "\n";
}

void Administracion::imprimirPropietariosConParqueadero()
{
    // Recorrer el arreglo e imprimir todos los propietarios que tienen parqueadero.
    for( int i = 0; i < propietarios.size(); i++ ){
        if( propiedades[ i ].getParqueadero() == true ){
            propietarios[ i ].getNombreParqueadero();
            cout << " : Tiene parqueadero\n";
        }
    }
    numeroParqueadero();
}

void Administracion::recaudarAdministracion()
{
}