#include <iostream>
#include "propietario.h"

void Propietario::setIdentificacion( double identificacion ){
    this -> identificacion = identificacion; //Global = local
}

double Propietario::getIdentificacion(){
    return identificacion;
}

void Propietario::setNombre( string nombre ){
    this -> nombre = nombre;
}

void Propietario::setPropiedad( Propiedad propiedad ){
    this -> propiedad = propiedad;
}

void Propietario::getNombreParqueadero(){
    cout << "Nombre: " << nombre; 
}

void Propietario::Datospropietario(){
    cout<< "El nombre es " << nombre << "\n";
    cout<< "La identificacion es " << identificacion << "\n";
    propiedad.DatosPropiedad();
}
