/* Autor: Miguel Angel Sanchez Paez*/
#include <iostream>
#include "propietario.h"
#include "propiedad.h"
#include "administracion.h"

using std::cout;
using std::cin;
using std::string;

void menu(Administracion administracion)
{
    int opc = 0;
    do
    {
        cout << "\nBienvenidos°°°°°    \n";
        cout << "1. Mostrar informacion \n";
        cout << "2. Propietarios con Parqueadero\n" ;
        cout << "0. Salir \n\n";
        cout << "Opcion: ";

        cin >> opc;

        switch (opc)
        {
        case 1:
            administracion.imprimirPropietarios();
            break;
        case 2:
            administracion.imprimirPropietariosConParqueadero();
            break;
        default:
            break;
        }
    } while (opc != 0);
}

int main()
{
    /*string nombre;
    cout << "Funciono, escribe tu nombre: ";
    cin >> nombre;
    cout << "Tu nombre es: " << nombre;*/
    Administracion administracion;

    // Inicializar datos
    administracion.Informacion();
    menu(administracion);

    // TODO: Imprimir la informción de los propietarios que tengan parqueadero solamente
    // Decir cuantos propietarios tienen propiedades con parqueadero.
    return 0;
}