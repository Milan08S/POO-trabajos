#include <iostream>
#include "propiedad.h"

void Propiedad::pagarRecargo( float ){

}

void Propiedad::setArea( float area ){
    this -> area = area;
}

void Propiedad::setidPropiedad( double idPropiedad ){
    this -> idPropiedad = idPropiedad;
}

void Propiedad::setPiso( int piso ){
    this -> piso = piso;
}

void Propiedad::setParqueadero( bool parqueadero ){
    this -> parqueadero = parqueadero;
}

int Propiedad::getParqueadero(){
    if( parqueadero == true ){
        return true;
    }
    return 0;
}

void Propiedad::DatosPropiedad(){ //Sirve para mostrar los datos de las propiedades
    cout << "La propiedad es " << idPropiedad << "\n";
    cout << "El piso es " << piso << "\n";
    cout << "El area es " << area << "\n";
    cout << "Tiene Parqueadero " << parqueadero << "\n";

}