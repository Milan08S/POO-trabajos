#include <iostream>
#include "administracion.h" 

void Administracion::Informacion(){
    Propietario propieta1, propieta2, propieta3, propieta4, propieta5, propieta6;

    propieta1.setNombre( "Debora Vilar" ); //aqui se coloca la informacion en las clases
    propieta1.setIdentificacion( 20202492 );
    propieta2.setNombre( "Ignacio Rodríguez " );
    propieta2.setIdentificacion( 30458452  );
    propieta3.setNombre( "Erika Muñoz " );
    propieta3.setIdentificacion( 1058845781 );
    propieta4.setNombre( "Modesto Villaverde " );
    propieta4.setIdentificacion( 31321432 );
    propieta5.setNombre( "Camilo Torres" );
    propieta5.setIdentificacion( 4476283  );
    propieta6.setNombre( "Sebastian Agudelo" );
    propieta6.setIdentificacion( 30432176 );


    Propiedad prop1, prop2, prop3, prop4, prop5, prop6; //aqui creamos las propiedades

    prop1.setidPropiedad( 101 ); //Le asignamos la id a las propiedades
    prop2.setidPropiedad( 901 );
    prop3.setidPropiedad( 701  );
    prop4.setidPropiedad( 502 );
    prop5.setidPropiedad( 102 );
    prop6.setidPropiedad( 902 );

    prop1.setPiso( 10 ); //Le asignamos el piso a la propiedad
    prop2.setPiso( 9 );
    prop3.setPiso( 7 );
    prop4.setPiso( 5 );
    prop5.setPiso( 10 );
    prop6.setPiso( 9 );

    prop1.setArea( 160 ); //Le asignamos el area a cada propiedad
    prop2.setArea( 30 );
    prop3.setArea( 45 );
    prop4.setArea( 60 );
    prop5.setArea( 55 );
    prop6.setArea( 100 );

    prop1.setParqueadero( true );
    prop2.setParqueadero( false );
    prop3.setParqueadero( true );
    prop4.setParqueadero( false );
    prop5.setParqueadero( true );
    prop6.setParqueadero( false );

    prop1.setOcupado( true ); //ocupado == true, desocupado == false
    prop2.setOcupado( true );
    prop3.setOcupado( true );
    prop4.setOcupado( false );
    prop5.setOcupado( true );
    prop6.setOcupado( false );

    propieta1.setPropiedad( prop1 ); //Le asignamos la propiedad al propietario
    propieta2.setPropiedad( prop2 );
    propieta3.setPropiedad( prop3 );
    propieta4.setPropiedad( prop4 );
    propieta5.setPropiedad( prop5 );
    propieta6.setPropiedad( prop6 );

    //incluir los propietarios en el vector(lista)

    propietarios.push_back( propieta1 ); //push back es como el append de python
    propietarios.push_back( propieta2) ;
    propietarios.push_back( propieta3 );
    propietarios.push_back( propieta4 );
    propietarios.push_back( propieta5 );
    propietarios.push_back( propieta6 );

    propiedades.push_back( prop1 );
    propiedades.push_back( prop2 );
    propiedades.push_back( prop3 );
    propiedades.push_back( prop4 );
    propiedades.push_back( prop5 );
    propiedades.push_back( prop6 );
    
    return;
}

void Administracion::imprimirPropietarios()
{
    // Recorrer el arreglo e imprimir todos los propietarios
    for (int i = 0; i < propietarios.size(); i++)
    {
        propietarios[ i ].Datospropietario();
    }
}

void Administracion::numeroParqueadero(){
    int numSTP = 0; //STP: si tiene parqueadero
    int numNTP = 0;
    for( int i = 0; i < propietarios.size(); i++ ){
        if( propiedades[ i ].getParqueadero() == true ){
            numSTP++;
        }
        else{
            numNTP++;
        }
    }
    cout << "El numero de propietarios con parqueadero es " << numSTP << "\n";
    cout << "El numero de propietarios sin parqueadero es " << numNTP << "\n";
}

void Administracion::imprimirOcupados(){
    for( int i = 0; i < propietarios.size(); i++ ){
        if( propietarios[ i ].getPropiedad().getOcupado() == false ){
            cout << "Propiedad de " << propietarios[ i ].getNombre() << "\n";
        }
    }
}

void Administracion::imprimirPropietariosConParqueadero()
{
    // Recorrer el arreglo e imprimir todos los propietarios que tienen parqueadero.
    for( int i = 0; i < propietarios.size(); i++ ){
        if( propiedades[ i ].getParqueadero() == true ){
            cout << propietarios[ i ].getNombre();
            cout << " : Tiene parqueadero\n";
        }
    }
}

void Administracion::recaudarAdministracion(){
    int total = 0;
    for( int i = 0; i < propietarios.size(); i++ ){
        total += propietarios[ i ].pagarAdmin();
    }
    cout << "El total a recaudar es: " << total << "\n";
    
}

void Administracion::imprimirPropiedadesPiso( int piso ){
    propietarios[ piso ].getPropiedad().getIdPropiedad();
}

void Administracion::imprimirParqueaderosPiso(){
    int numSTP = 0;
    int np = 10; //numero de pisos
    for( int i = 0; i < np; i++ ){
        if( propiedades[ i ].getParqueadero() == true ){
            numSTP++;
        }
        cout << "piso " << i+1 << "\n";
        cout << "Numero de parqueaderos: " << numSTP << "\n";
        numSTP = 0;
    }
}

void Administracion::imprimirPisoPropietario(){
    float mts = 50;
    for( int i = 0; i < propietarios.size(); i++){
        if(propietarios[ i ].getPropiedad().getArea() > mts ){
            cout << "El propietario es " << propietarios[ i ].getNombre() << "\n";
            cout << "El piso es " << propietarios[ i ].getPropiedad().getPiso() << "\n\n";
        }
    }

}