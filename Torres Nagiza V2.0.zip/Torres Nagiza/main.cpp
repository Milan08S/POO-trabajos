/* Autor: Miguel Angel Sanchez Paez
Github: Milan08S **Nombre artistico**
Proyecto: Torres de Niza
Version: 2.0
*/
#include <iostream>
#include "propietario.h"
#include "propiedad.h"
#include "administracion.h"

using std::cout;
using std::cin;
using std::string;

void menu(Administracion administracion)
{
    int opc = 0;
    int piso;
    do
    {
        cout << "\nBienvenidos°°°°°    \n";
        cout << "1. Mostrar informacion \n";
        cout << "2. Propietarios con Parqueadero\n" ;
        cout << "3. Numero propietarios con y sin parqueadero\n";
        cout << "4. Propietarios con mas de 50 mts\n";
        cout << "5. Propiedades en el piso\n";
        cout << "6. Propiedades desocupadas\n";
        cout << "7. Parqueaderos por piso\n";
        cout << "8. Pago propietario\n";
        cout << "0. Salir \n\n";
        cout << "Opcion: ";

        cin >> opc;

        switch (opc)
        {
        case 1:
            administracion.imprimirPropietarios();
            break;
        case 2:
            administracion.imprimirPropietariosConParqueadero();
            break;
        case 3:
            administracion.numeroParqueadero();
            break;
        case 4:
            administracion.imprimirPisoPropietario();
            break;
        case 5:
            cout << "Ingrese el numero del piso: ";
            cin >> piso;
            administracion.imprimirPropiedadesPiso( piso );
            break;
        case 6:
            cout << "Las propiedades desocupadas son:\n";
            administracion.imprimirOcupados();
            break;
        case 7:
            administracion.imprimirParqueaderosPiso();
            break;
        case 8:
            administracion.recaudarAdministracion();
            break;
        default:
            break;
        }
    } while (opc != 0);
}

int main()
{
    /*string nombre;
    cout << "Funciono, escribe tu nombre: ";
    cin >> nombre;
    cout << "Tu nombre es: " << nombre;*/
    Administracion administracion;

    // Inicializar datos
    administracion.Informacion();
    menu(administracion);

    // TODO: Imprimir la informción de los propietarios que tengan parqueadero solamente
    // Decir cuantos propietarios tienen propiedades con parqueadero.
    return 0;
}