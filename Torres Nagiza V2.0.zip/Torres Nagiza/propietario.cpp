#include <iostream>
#include "propietario.h"

void Propietario::setIdentificacion( double identificacion ){
    this -> identificacion = identificacion; //Global = local
}

double Propietario::getIdentificacion(){
    return identificacion;
}

void Propietario::setNombre( string nombre ){
    this -> nombre = nombre;
}

void Propietario::setPropiedad( Propiedad propiedad ){
    this -> propiedad = propiedad;
}

string Propietario::getNombre(){
    return nombre; 
}

int Propietario::pagarAdmin(){
    int ca = 2000; //cobro ascensor
    int cap = 50000; //cobro apartamento
    float rec = 0.05; //recargo del 5 porciento
    int ct = 0; //cobro total

    if( propiedad.getArea() > 50 ){
        int sob = cap*rec; //sobrante
        ct += sob;
    }

    ct += cap;
    int cat = ca * propiedad.getPiso(); // cobro ascensor total
    ct += cat; 

    return ct;
}

void Propietario::Datospropietario(){
    cout<< "El nombre es " << nombre << "\n";
    cout<< "La identificacion es " << identificacion << "\n";
    propiedad.DatosPropiedad();
}

Propiedad Propietario::getPropiedad(){
    return this -> propiedad;
}
