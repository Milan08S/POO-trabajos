#ifndef PROPIETARIO_H
#define PROPIETARIO_H

#include <iostream>
#include "propiedad.h"

using std::cout;
using std::cin;
using std::string;

class Propietario{
    private:
        double identificacion;
        string nombre;
        Propiedad propiedad;
    public:
        double getIdentificacion();
        string getNombre();
        void setIdentificacion( double identificacion );
        void setNombre( string nombre );
        void setPropiedad( Propiedad propiedad );
        int pagarAdmin();
        void Datospropietario();
        Propiedad getPropiedad();
};
#endif