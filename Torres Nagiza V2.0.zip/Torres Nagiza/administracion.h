#ifndef ADMINISTRACION_H
#define ADMINISTRACION_H

#include <iostream>
#include "propiedad.h"
#include "propietario.h"
#include <vector>

using std::string;
using std::vector; //un vector es basicamente una lista

class Administracion
{
private:
    int cobroAscensor;
    int cobroBase;
    float recargo;
    vector<Propietario> propietarios; //siempre se coloca en el vector en plural, por ejemplo, propietario, propietarios
    vector<Propiedad> propiedades;

public:
    void Informacion(); //pasamos el incializar datos de main a administracion cpp
    void imprimirPropietariosConParqueadero(); // TO-DO
    void imprimirPropietarios();
    void imprimirPropiedadesPiso( int piso ); //imprime las propiedades de un piso
    void imprimirOcupados();
    void recaudarAdministracion();
    void imprimirParqueaderosPiso(); //imprime los paruqeaderos por piso
    void numeroParqueadero();
    void imprimirPisoPropietario(); //imprime las propiedades mayor a 50mts, su piso y propietario
    void setCobroAscensor();
    void setCobroBase();
    void setRecargo();
    int getCobroAscensor();
    int getCobroBase();
    float getRecargo();
};


#endif