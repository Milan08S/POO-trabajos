#include <iostream>
#include "propiedad.h"

void Propiedad::setArea( float area ){
    this -> area = area;
}

void Propiedad::setOcupado( bool ocupado ){
    this -> ocupado = ocupado;
}

bool Propiedad::getOcupado(){
    return ocupado;
}

double Propiedad::getIdPropiedad(){
    return idPropiedad;
}

void Propiedad::setidPropiedad( double idPropiedad ){
    this -> idPropiedad = idPropiedad;
}

void Propiedad::setPiso( int piso ){
    this -> piso = piso;
}

void Propiedad::setParqueadero( bool parqueadero ){
    this -> parqueadero = parqueadero;
}

void Propiedad::DatosPropiedad(){ //Sirve para mostrar los datos de las propiedades
    cout << "La propiedad es " << idPropiedad << "\n";
    cout << "El piso es " << piso << "\n";
    cout << "El area es " << area << "\n";
    cout << "Tiene Parqueadero " << parqueadero << "\n\n";

}

bool Propiedad::getParqueadero(){
    return parqueadero;
}

float Propiedad::getArea(){
    return area;
}

int Propiedad::getPiso(){
    return piso;
}