#ifndef INQUILINO_H
#define INQUILINO_H

#include <iostream>

using std::cout;
using std::cin;
using std::string;

class Inquilino{
    private:
        double identificacion_I; //las variables con los mismos nombres de otras clases tendran una I para decir que es de Inquilino
        string nombre_I;
        string direccion_I;
        double fecha_inicio;
        double fin_contrato;
        int alquiler;
    public:
        string getNombre();
        void setNombre( string nombre_I);
        double getIdentificacion();
        void setIdentificacion( double identificacion_I);
        string getDireccion();
        void setDireccion( string direccion_I);
        double getFecha_inicio();
        void setFecha_inicio( double fecha_inicio);
        double getFin_contrato();
        void setFin_contrato( double fin_contrato );
        int getAlquiler();
        void setAlquiler( int alquiler );
};

#endif